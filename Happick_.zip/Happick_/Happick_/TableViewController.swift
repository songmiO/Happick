//
//  TableViewController.swift
//  Happick_
//
//  Created by chole on 2020/09/14.
//  Copyright © 2020 Claire. All rights reserved.
//

import UIKit


class TableViewController: UITableViewController {

}
