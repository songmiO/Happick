//
//  CollectionTableViewCell.swift
//  Happick_
//
//  Created by j on 2020/01/28.
//  Copyright © 2020 Claire. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {


    @IBOutlet weak var numberRecordLabel: UILabel!

    @IBOutlet weak var dateLabel: UILabel!

    @IBOutlet weak var myPhotoImageView: UIImageView!
    
    @IBOutlet weak var contentTextVIew: UITextView!
}
