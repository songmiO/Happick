//
//  LaunchTableViewController.swift
//  Happick_
//
//  Created by chole on 2021/01/11.
//  Copyright © 2021 Claire. All rights reserved.
//

import UIKit

class LaunchTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        Thread.sleep(forTimeInterval: 3.0)
        // Override point for customization after application launch.
        return true
    }

    }

}
