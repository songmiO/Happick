//
//  TextViewController.swift
//  Happick_
//
//  Created by j on 2020/01/28.
//  Copyright © 2020 Claire. All rights reserved.
//

import UIKit
import YPImagePicker

class TextViewController: UIViewController,UITextViewDelegate {


@IBOutlet weak var NowDate: UILabel!

@IBOutlet weak var TextView: UITextView!

@IBOutlet weak var ButtonView: UIView!
        
@IBOutlet weak var CameraButton: UIButton!
        
@IBOutlet weak var DoneButton: UIButton!
    

override func viewDidLoad() {
    
         super.viewDidLoad()
    
         self.TextView.delegate = self
    
         let toolBar = UIToolbar()
         toolBar.sizeToFit()

         let date = Date()
            
         let formatter = DateFormatter()
            formatter.locale = .current
            formatter.dateFormat = "YYYY. MM. DD"
            NowDate.text = formatter.string(from: date)
    
    
         

         func textAlignmentSetting() {
         NowDate.textAlignment = .center

         TextView.delegate = self
    }

//        //버튼 클릭 액션 설정
//        self.CameraButton.addTarget(self, action: #selector(onCameraButtonClicked), for: .touchUpInside)

}
    

        

    
    
    
    @IBAction func CameraButton(_ sender: UIButton) {
        
        let picker = YPImagePicker()
            
            picker.didFinishPicking { [unowned picker] items, _ in
            
        if let photo = items.singlePhoto {
            print(photo.fromCamera) // Image source (camera or library)
            print(photo.image) // Final image selected by the user
            print(photo.originalImage) // original image selected by the user, unfiltered
            print(photo.modifiedImage) // Transformed image, can be nil
            print(photo.exifMeta) // Print exif meta data of original image.
        }
            
                
            
            //사진 선택창 닫기
            picker.dismiss(animated: true, completion: nil)

        }
           //사진 선택창 보여주기
            self.present(picker, animated: true, completion: nil)
            
            
        }
    
    override func viewWillAppear(_ animated: Bool) {
            //화면이 표시될때, Keyboard표시에 대한 이벤트가 발생하면 호출되는 함수를 등록한다.
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
        }
    
        func keyboardWillShow(_ notification:NSNotification) {
            //키보드가 표시 될때, ButtonView의 위치를 올려준다.
            moveButtonViewUp(with: notification)
        }
        func keyboardWillHide(_ notification:NSNotification) {
            //키보드가 사라질 때, ButtonView의 위치를 아래로 내려준다.
            moveButtonViewDown(with: notification)
        }
    

    
    fileprivate func moveToolbarUp(with notification:NSNotification) {
         self.moveToolBar(isUp: true, with: notification)
     }
     fileprivate func moveToolbarDown(with notification:NSNotification) {
         self.moveToolBar(isUp: false, with: notification)
     }
     fileprivate func moveToolBar(isUp up:Bool, with notification:NSNotification) {
         if let userInfo = notification.userInfo {
             //let beginFrame = (userInfo[UIKeyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
            let endFrame = (userInfo[UIResponder.keyboardFrameEndUserInfoKey] as! NSValue).cgRectValue
             let duration = (userInfo[UIKeyboardAnimationDurationUserInfoKey] as! NSNumber).doubleValue
             let animationOptions = UIViewAnimationOptions(rawValue: (userInfo[UIKeyboardAnimationCurveUserInfoKey] as! NSNumber).uintValue)
             
             let frame = self.toolbar.frame
             let rect:CGRect = CGRect(x: frame.origin.x,
                                      y: frame.origin.y + endFrame.size.height * (up ? -1 : 1),
                                      width: frame.size.width,
                                      height: frame.size.height)
             UIView.animate(withDuration: duration,
                            delay: 0.0,
                            options: animationOptions,
                            animations: { () -> Void in
                             self.toolbar.frame = rect
             }, completion: nil)
             
         }else{
             //UserInfo가 없을 경우..
         }
    }
        
}
    
    









