//
//  TableViewCell.swift
//  Happick_
//
//  Created by chole on 2020/09/14.
//  Copyright © 2020 Claire. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var dateLabel: UILabel!
    
    @IBOutlet weak var photoImageView: UIImageView!
    let imagePicker: UIImagePickerController! = UIImagePickerController()
    //사진 저장 변수
    var captureImage: UIImage!
    //사진 저장 여부 변수
    var imageSave = false
    

    @IBOutlet weak var contentsTextView: UITextView!
    
    
}
