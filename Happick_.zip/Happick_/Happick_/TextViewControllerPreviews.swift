//
//  TextViewControllerPreviews.swift
//  Happick_
//
//  Created by chole on 2021/01/30.
//  Copyright © 2021 Claire. All rights reserved.
//

import Foundation
import SwiftUI

struct TextViewControllerPreviews : PreviewProvider, UIViewRepresentable {
   
    typealias UIViewControllerType = TextViewController
    
    func makeUIViewController(context: UIViewControllerRepresentableContext<TextViewControllerPreviews>) ->
    TextViewController {
        
        let storyboard = UIStoryboard(name : "Main", bundle: nil)
        return storyboard.instantiateViewController(identifier: "TextViewController")
    }
    
    func updateUIViewController(_ uiViewController: TextViewController, context : UIViewControllerRepresentableContext<TextViewControllerPreviews>) {
    }
    
    static var previews: some View {
        TextViewControllerPreviews()
    }
}
