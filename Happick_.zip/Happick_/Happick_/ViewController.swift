//
//  ViewController.swift
//  Happick_
//
//  Created by j on 2020/01/28.
//  Copyright © 2020 Claire. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

